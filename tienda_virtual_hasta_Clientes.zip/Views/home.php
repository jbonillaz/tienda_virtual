<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mini Framework - AbelOSh</title>
</head>
<body>
    <p>Mini Framework V1.0 - <a href="https://abelosh.com">www.abelosh.com</a></p>
</body>
</html>